# the script was made to reactivate an old function of the application: “Flex3 Beta”

# - the function is the old async function of “kill process”. Which was previously removed from flex for rootless and Bootstrap.

# - The script was made for this function to be implemented again.

#################################

# >> Support for: arm64 and arm64e; Rootless / palera1n and Bootstrap.

- does not support: Dopamine (support will be added soon!)

#################################

# - functions: RefreshApp's automatic | capture appsName with bundleID with apiget.
